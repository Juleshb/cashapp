-- AlterTable
ALTER TABLE "vip_levels" ADD COLUMN     "bicycleColor" TEXT,
ADD COLUMN     "bicycleFeatures" TEXT,
ADD COLUMN     "bicycleModel" TEXT;
