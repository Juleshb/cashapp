-- AlterTable
ALTER TABLE "deposits" ADD COLUMN     "depositType" TEXT,
ADD COLUMN     "network" TEXT;
