-- AlterTable
ALTER TABLE "admin_settings" ADD COLUMN     "minUsdtDepositAmount" DECIMAL(18,8) NOT NULL DEFAULT 30;
