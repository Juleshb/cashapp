-- AlterTable
ALTER TABLE "deposits" ADD COLUMN     "adminNotes" TEXT;
