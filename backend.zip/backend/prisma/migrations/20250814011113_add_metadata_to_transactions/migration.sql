-- AlterTable
ALTER TABLE "transactions" ADD COLUMN     "metadata" JSONB;
