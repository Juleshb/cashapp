/*
  Warnings:

  - You are about to drop the column `referralBonusRate` on the `admin_settings` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "admin_settings" DROP COLUMN "referralBonusRate";
